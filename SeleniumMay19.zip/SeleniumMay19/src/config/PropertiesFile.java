package config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import SelMay19.BrowserWithProperties;

public class PropertiesFile {

	// let other methods (main) access properties object  
	static Properties prop = new Properties();
	
	//read from and write to properties file
	public static void main(String[] args) {
		readPropertiesFile();
		writePropertiesFile();
	}
	
	public static void readPropertiesFile() {
		
		try {
			//create new input stream and load properties to object
			InputStream input = new FileInputStream("C:\\Users\\peter.iversen\\JavaTraining\\SeleniumMay19\\src\\config\\config.properties");
			prop.load(input);
			System.out.println("The value of the 'browser' property in config.properties is: " + prop.getProperty("browser"));
			BrowserWithProperties.browser = prop.getProperty("browser");
			System.out.println("The value of the 'browser' variable assigned to main program is: " + BrowserWithProperties.browser);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void writePropertiesFile() {
		try {
			OutputStream output = new FileOutputStream("C:\\Users\\peter.iversen\\JavaTraining\\SeleniumMay19\\src\\config\\config.properties");
			//Modify browser property (or insert it if it doesn't already exist):
			
			// Toggle the browser value each time it's used 
			String newBrowser = "Edge";
			System.out.println("Writing properties file.... what is the current browser set to?  " + prop.getProperty("browser") + "!");
			if (prop.getProperty("browser").contains("Chrome")) {
				prop.setProperty("browser", newBrowser);
				prop.store(output, "on the cusp!");
			} else {
				prop.setProperty("browser","Chrome");
				prop.store(output, "silvery?");
			}
			System.out.println("The value of the 'browser' property now is: " + prop.getProperty("browser"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

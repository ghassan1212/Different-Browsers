package SelMay19;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import config.PropertiesFile;

//This class uses the Config/Properties files to set the browser instead of running the setBrowser() method.\
//Otherwise, this class is identical to Browser21TNG (runs 3 browser tests with drop/check boxes).
public class BrowserWithProperties {
	//browser variable needs to be public to give the Properties class access.
	public static String browser;
	WebDriver dr;            
	static int count = 0;

	@BeforeClass  // read the browser value from config.properties into the browser variable 
	public void bclass() {
		PropertiesFile.readPropertiesFile();
	}
	
	@AfterClass  // read the browser value from config.properties into the browser variable 
	public void aclass() {
		PropertiesFile.writePropertiesFile();
	}
	
	@BeforeMethod
	public void hello() {

		System.out.println("Before Method Greeting:  Hey, it's method #" + ++count + "!");
	}

	@Test	//Get the full list of elements from a drop down box
	public void testADropDown()
	{
		//System.out.println("Let's try getting a list from a drop down box after selecting a couple items...");
		//System.setProperty("webdriver.chrome.driver", "C:\\Temp\\ChromeDriver\\chromedriver.exe");
		//ChromeOptions options = new ChromeOptions();
		//options.setExperimentalOption("useAutomationExtension", false);
		//options.addArguments("disable-infobars");
		//dr = new ChromeDriver(options);
		//dr.navigate().to("http://google.com");
		//		Navigate to a website with a dropdown box...
		//setBrowser("Edge");
		setBrowserConfig();
		
		dr.navigate().to("http://jsbin.com/osebed/");
		//WebElement dropBox1 = dr.findElement(By.id("fruits"));   //checkbox only!!!
		Select dbSelect = new Select(dr.findElement(By.id("fruits")));
		dbSelect.selectByVisibleText("Orange");
		dbSelect.selectByVisibleText("Grape");
		String fruit = dr.findElement(By.xpath("//*[@id=\"fruits\"]/option[3]")).getText();		
		System.out.println("One fruit:  " + fruit);
		// assign the whole list of elements to String variable and print
		String fruitList = dr.findElement(By.xpath("//*[@id=\"fruits\"]")).getText();	
		System.out.println("Fruits list:  \n" + fruitList);
	}

	//set which browser to be used for test
	public void setBrowser(String s) {
		browser=s;
	}
	
	//configure web driver based on browser
	public void setBrowserConfig() {
		//for ChromeOptions
		if (browser.contains("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Temp\\ChromeDriver\\chromedriver.exe");
 			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("useAutomationExtension", false);
			options.addArguments("disable-infobars");
			dr = new ChromeDriver(options);
		}
		
		//for Edge
		if (browser.contains("Edge")) {	
			System.setProperty("webdriver.edge.driver", "C:\\Temp\\EdgeDriver\\msedgedriver.exe");
			dr = new EdgeDriver();
		}
	}
	
	@Test	//  Single Check box check test
	public void testCheckBox() {
		//Try checking a check box
//		System.out.println("Now let's try to check a check box...");
//		System.setProperty("webdriver.chrome.driver", "C:\\Temp\\ChromeDriver\\chromedriver.exe");
//		ChromeOptions options = new ChromeOptions();
//		options.setExperimentalOption("useAutomationExtension", false);
//		options.addArguments("disable-infobars");
//		dr = new ChromeDriver(options);
		//setBrowser("Chrome");
		setBrowserConfig();
		dr.navigate().to("http://jsbin.com/");
		WebElement checkBox = dr.findElement(By.xpath("//*[@id=\"enableUniversalEditor\"]"));
		checkBox.click();
		System.out.println("Checked the lone checkbox.");

	}

	@Test	//  Multiple Check box check test
	public void testMultipleCheckBox() {
		//Try checking all check boxes
/*		System.out.println("And last but not least, let's check multiple check boxes...");
		System.setProperty("webdriver.chrome.driver", "C:\\Temp\\ChromeDriver\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("disable-infobars");
		dr = new ChromeDriver(options);
*/		
		//setBrowser("Chrome");
		setBrowserConfig();
		dr.navigate().to("https://ironspider.ca/forms/checkradio.htm");
		
		//I can scroll through them because I know how many there are, but if I didn't know how many, could I use a for-each loop?
		// How can I get the object that represents all checkboxes?
		// A regular for loop doesn't work as the xpath doesn't accept variables in the index!
		/*for (int i=1; i<7; i++ ) {
			WebElement checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[i]"));
			checkBox.click();
			
		}*/
		WebElement checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[1]"));
		checkBox.click();
		checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[2]"));
		checkBox.click();
		checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[3]"));
		checkBox.click();
		checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[4]"));
		checkBox.click();
		checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[5]"));
		checkBox.click();
		checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[6]"));
		checkBox.click();
	
		//WebElement checkBox = dr.findElement(By.xpath("//*[@id=\"Content\"]/div[1]/blockquote[1]/form/input[i]"));
		
		System.out.println("Checked all checkboxes.");
		
		
	}
	
	@AfterMethod	//close browser
	public void afterm() {
		//dr.close();
		dr.quit();
	}	
}

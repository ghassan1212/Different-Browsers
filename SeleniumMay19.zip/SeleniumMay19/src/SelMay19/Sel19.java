package SelMay19;

public class Sel19 {

	//practise static variables and methods!

	public static void main(String[] args) 
	{

		//used code from Youtube video "#13.1 Java STATIC keyword: Static Variable and Methods Part-1.Object Oriented Java Tutorial"
		int l = 2;
		int b = 10;
		//call static method from Rectangle class
		int areaS = Rectangle.getAreaS(l,b);
		System.out.println("Area of " + l + " by " + b + " rectangle is: " + areaS);

		//call dynamic method from Rectangle object
		Rectangle e1 = new Rectangle();
		int areaD = e1.getAreaD(l, b);
		System.out.println("Area of " + l + " by " + b + " rectangle is: " + areaD);

		// increment variables to see their effect on calculations
		System.out.println("Number of times Rectangle methods have been called: " + Rectangle.methodCounter);
		while (Rectangle.methodCounter < 10) 
		{
			System.out.println("Area of " + ++l + " by " + ++b + " rectangle is: " + Rectangle.getAreaS(l, b));
		} 
		System.out.println("Number of times Rectangle methods have been called: " + Rectangle.methodCounter);

	}

}

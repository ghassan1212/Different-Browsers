package SelMay19;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class LocatorBasic {

	// Attempt to open ITRDS and login
	// Previous attempt failed to setBrowserConfig() so this will put all code in the main method instead.
	public static void main(String[] args) {
		
		System.setProperty("webdriver.edge.driver", "C:\\Temp\\EdgeDriver\\msedgedriver.exe");
		WebDriver dr = new EdgeDriver();
		System.out.println("navigating to ITRDS now...");
		dr.navigate().to("https://itrds-s.intra.dev/stream2/cs/");
		//linkText() does not work
		//dr.findElement(By.linkText("English")).click();
		//partialLinkText() does not work.
		//dr.findElement(By.partialLinkText("English")).click();
		
		System.out.println("English button has been pressed!");
	}
}

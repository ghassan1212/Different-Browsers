package SelMay19;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import config.PropertiesFile;

// test out Locators using ITRDS S2
public class Locators25 {
	//browser variable needs to be public to give the Properties class access.
	public static String browser;
	WebDriver dr;            
	static int count = 0;

	@BeforeClass  // read the browser value from config.properties into the browser variable 
	public void bclass() {
		System.out.println("Reading properties file now....");
		PropertiesFile.readPropertiesFile();
	}

	@AfterClass  // read the browser value from config.properties into the browser variable 
	public void aclass() {
		System.out.println("Writing properties file now....");
		PropertiesFile.writePropertiesFile();
	}

	@BeforeMethod
	public void hello() {

		System.out.println("Before Method Greeting:  Hey, it's method #" + ++count + "!");
	}

	//Login to ITRDS
	@Test	
	public void testLogin(){
		//set the browser of choice
		System.out.println("setting Browser now...");
		setBrowserConfig();
		//navigate to ITRDS S2
		System.out.println("navigating to ITRDS now...");
		dr.navigate().to("https://itrds-s.intra.dev/stream2/cs/");
		//dr.findElement(By.linkText("English")).click();
		System.out.println("English button has been pressed!");
	}

	//configure web driver based on browser
	public void setBrowserConfig() {
		//for ChromeOptions
		System.out.println("Inside the setBrowserConfig() method now...");
		if (browser.contains("Chrome")) {
			System.out.println("   ...about to setProperty()");
			System.setProperty("webdriver.chrome.driver", "C:\\Temp\\ChromeDriver\\chromedriver.exe");
			System.out.println(("   ...about to declare ChromeOptions"));
			ChromeOptions options = new ChromeOptions();
			System.out.println("   ...about to setExperimentalOption()");
			options.setExperimentalOption("useAutomationExtension", false);
			System.out.println("   ...about to addArguments()");
			options.addArguments("disable-infobars");
			System.out.println("   ...about to assign new ChromeDriver() to dr object!");
			dr = new ChromeDriver(options);
		}
		System.out.println("setBrowserMethod has completed Chrome section; now beginning Edge...");
		//for Edge
		if (browser.contains("Edge")) {	
			System.setProperty("webdriver.edge.driver", "C:\\Temp\\EdgeDriver\\msedgedriver.exe");
			dr = new EdgeDriver();
		}
		
		System.out.println("setBrowserMethod completed successfully!");
	}

	@AfterMethod	//close browser
	public void aftermeth() {
		//dr.close();
		dr.quit();
	}	
}

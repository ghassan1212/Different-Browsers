package SelMay19;

public class Rectangle {

	static int methodCounter = 0;
	
	public int getAreaD(int l, int b) {
		methodCounter++;
		return l * b;
	}

	public static int getAreaS(int l, int b) {
		methodCounter++;
		return l * b;
	
	}

}
